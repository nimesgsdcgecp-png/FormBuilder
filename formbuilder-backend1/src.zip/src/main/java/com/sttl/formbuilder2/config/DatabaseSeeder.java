package com.sttl.formbuilder2.config;

import com.sttl.formbuilder2.model.entity.AppUser;
import com.sttl.formbuilder2.model.entity.Permission;
import com.sttl.formbuilder2.model.entity.Role;
import com.sttl.formbuilder2.model.entity.UserFormRole;
import com.sttl.formbuilder2.repository.PermissionRepository;
import com.sttl.formbuilder2.repository.RoleRepository;
import com.sttl.formbuilder2.repository.UserFormRoleRepository;
import com.sttl.formbuilder2.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Configuration
@RequiredArgsConstructor
@Slf4j
@Order(1)
public class DatabaseSeeder implements CommandLineRunner {

    private final RoleRepository roleRepository;
    private final PermissionRepository permissionRepository;
    private final UserRepository userRepository;
    private final UserFormRoleRepository userFormRoleRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        log.info("Starting Database Seeding...");

        // 1. Seed Exact Legacy Permissions
        Permission readPerm = createPermissionIfNotFound("READ", "Read form", "FORM");
        Permission writePerm = createPermissionIfNotFound("WRITE", "Write form", "FORM");
        Permission editPerm = createPermissionIfNotFound("EDIT", "Edit form", "FORM");
        Permission deletePerm = createPermissionIfNotFound("DELETE", "Delete form", "FORM");
        Permission approvePerm = createPermissionIfNotFound("APPROVE", "Approve form", "FORM");
        Permission managePerm = createPermissionIfNotFound("MANAGE", "Manage admin", "ADMIN");
        Permission exportPerm = createPermissionIfNotFound("EXPORT", "Export data", "FORM");
        Permission auditPerm = createPermissionIfNotFound("AUDIT", "Audit access", "ADMIN");
        Permission visibilityPerm = createPermissionIfNotFound("VISIBILITY", "Visibility control", "FORM");
        
        List<Permission> allPerms = List.of(readPerm, writePerm, editPerm, deletePerm, approvePerm, managePerm, exportPerm, auditPerm, visibilityPerm);
        List<Permission> formBuilderPerms = List.of(readPerm, writePerm, editPerm, deletePerm, exportPerm, visibilityPerm, approvePerm);

        log.info("Permissions seeder finished.");

        // 2. Seed Legacy Roles
        Role adminRole = createRoleIfNotFound("ADMIN", "System Administrator", allPerms);
        Role roleAdmin = createRoleIfNotFound("ROLE_ADMINISTRATOR", "Permissions Manager", List.of(managePerm, auditPerm, readPerm));
        Role builderRole = createRoleIfNotFound("BUILDER", "Form Builder", formBuilderPerms);
        Role userRole = createRoleIfNotFound("USER", "Standard Registered User", List.of(readPerm, writePerm));

        log.info("Roles seeder finished.");

        // 3. Seed Default Users for each role
        createUserIfNotFound("admin", "admin123", adminRole);
        createUserIfNotFound("role_admin", "admin123", roleAdmin);
        createUserIfNotFound("builder", "builder123", builderRole);
        createUserIfNotFound("user", "user123", userRole);

        log.info("Users seeder finished! Database is ready to use.");
    }

    private Permission createPermissionIfNotFound(String name, String description, String category) {
        Optional<Permission> permissionOpt = permissionRepository.findByName(name);
        if (permissionOpt.isPresent()) {
            return permissionOpt.get();
        }
        Permission permission = new Permission();
        permission.setName(name);
        permission.setDescription(description);
        permission.setCategory(category);
        return permissionRepository.save(permission);
    }

    private Role createRoleIfNotFound(String name, String description, List<Permission> permissions) {
        Optional<Role> roleOpt = roleRepository.findByName(name);
        if (roleOpt.isPresent()) {
            return roleOpt.get();
        }
        Role role = new Role();
        role.setName(name);
        role.setDescription(description);
        role.setCreatedBy("SYSTEM");
        role.setCreatedAt(LocalDateTime.now());
        permissions.forEach(role::addPermission);
        return roleRepository.save(role);
    }

    private void createUserIfNotFound(String username, String password, Role role) {
        Optional<AppUser> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            return;
        }

        AppUser user = new AppUser();
        user.setUsername(username);
        user.setPasswordHash(passwordEncoder.encode(password));
        user.setDeleted(false);
        user = userRepository.save(user);

        UserFormRole userFormRole = new UserFormRole();
        userFormRole.setUser(user);
        userFormRole.setRole(role);
        userFormRole.setAssignedBy("SYSTEM");
        userFormRole.setAssignedAt(LocalDateTime.now());
        userFormRoleRepository.save(userFormRole);
    }
}
